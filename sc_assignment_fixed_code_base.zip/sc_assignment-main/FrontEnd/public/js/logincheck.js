
$(document).ready(function () {
    $("#userprofile").hide()
    $("#logincontainer").show()
    $("#logoutcontainer").hide()
    $("#admin").hide()

    const token = sessionStorage.getItem('JWT');
    const userData = sessionStorage.getItem("User");

    if (userData == null) return

    const { userid, type } = JSON.parse(userData)[0]

    const data = JSON.stringify({ userid, type })

    $.ajax({
        headers: { "authorization": "Bearer " + token },
        data: data,
        url: "https://localhost:8081/user/isloggedin",
        type: "POST",
        contentType: "application/json",
        dataType: "json",
        success: function (data, textStatus, xhr) {

            if (data != null) {
                isLoggedIn = true;
                let { userid, type } = data
                $("#logincontainer").hide()
                $("#logoutcontainer").show()
                $("#admin").hide()
                $("#userprofile").show()
                if (type.toLowerCase() == "admin") {
                    $("#admin").show()
                }
            }
        },
        error: function (xhr, textStatus, errorThrown) {
            $("#userprofile").hide()
            $("#logincontainer").hide()
            $("#logoutcontainer").hide()
            $("#admin").hide()
        }
    })

    $("#logout").click(function () {
        let cart = sessionStorage.getItem("Cart")
        sessionStorage.clear();
        sessionStorage.setItem("Cart", cart)
    })

})

