//checked thru alr

const validator = require('validator');

const validationFn = {
    validateRegister: function (req, res, next) {
        var username = req.body.username
        var password = req.body.password
        var email = req.body.email
        var contact = req.body.contact
        if (!/^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z0-9_]{4,16}$/.test(username)) {
            var error = { error: "Invalid characters in the username. There should be alphabets and number only. Only 4 - 16 characters are allowed." }
            console.log(error);
            return res.status(422).json(error);
        }
        if (!validator.isEmail(email)) {
            var error = { error: "Invalid email format." }
            console.log(error);
            return res.status(422).json(error);
        }
        if (!/^[89]\d{7}$/.test(contact)) {
            var error = { error: "Invalid contact number format. It should be in the format 8/9xxxxxxx." }
            console.log(error);
            return res.status(422).json(error);
        }
        if (!/^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*\W)(?!.* ).{8,16}$/.test(password)) {
            var error = { error: "Invalid password format. There should at least 8 characters, with a mix of upper and lower case alphabets, numbers and symbols" }
            console.log(error);
            return res.status(422).json(error);
        }
        next();
    },
    

    // not needed
    validateUserid: function (req, res, next) {
        const { userid } = req.params;

        // Check that userid is a valid number
        if (!validator.isInt(userid, { min: 1 })) {
            return res.status(500).json({ error: "Invalid userid." });
        }

        // If validation passes, proceed to the next middleware
        next();
    },

    // not needed
    sanitizeResult: function (result) {
        // Sanitize string values in the result array
        return result.map(record => {
            for (const key in record) {
                if (typeof record[key] === 'string') {
                    record[key] = validator.escape(record[key]);
                }
            }
            return record;
        });
    }
}

module.exports = validationFn;



        // ^: Asserts the start of the string.
        // [a-zA-Z0-9_]: Allows only alphanumeric characters (both uppercase and lowercase letters) and underscores.
        // {4,16}: Requires the username to be between 4 and 16 characters in length.
        // $: Asserts the end of the string.
        // Username must be alphanumeric and between 4 and 16 characters in length.




        // ^: Asserts the start of the string.
        // (?=.*[A-Za-z]): Positive lookahead to ensure at least one alphabet character.
        // (?=.*\d): Positive lookahead to ensure at least one digit.
        // (?=.*[@$!%*?&]): Positive lookahead to ensure at least one special character from the specified set.
        // [A-Za-z\d@$!%*?&]{8,}: Allows only the specified characters and requires a minimum length of 8 characters.
        // $: Asserts the end of the string.
        // Password must contain at least one alphabet, one digit, and one special character from @$!%*?&.