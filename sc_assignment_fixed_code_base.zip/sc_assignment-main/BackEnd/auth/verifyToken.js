var jwt = require('jsonwebtoken');
var secure = require('../model/secure.js');

async function verifyToken(req, res, next) {
    console.log(req.headers);
    var token = req.headers['authorization']; //retrieve authorization header's content
    console.log(token);

    if (!token || !token.includes('Bearer')) { //process the token
        res.status(403);
        return res.send({ auth: 'false', message: 'Not authorized!' });
    } else {
        token = token.split('Bearer ')[1]; //obtain the token's value

        //Generating secret
        console.log(jwt.decode(token, {complete: true}))
        const userid = jwt.decode(token, {complete: true}).payload.userid;
        
        try {
            var secret = await secure.get_info(userid);
            console.log(secret)
            jwt.verify(token, secret, function (err, decoded) { //verify token
                if (err) {
                    console.log("no")
                    console.log(err)
                    res.status(403);
                    return res.json({ auth: false, message: 'Not authorized!' });
                } else {
                    console.log(decoded)
                    console.log("yes")
                    req.userid = decoded.userid; //decode the userid and store in req for use
                    req.type = decoded.type; //decode the role and store in req for use
                    next();
                }
            });
        } catch (err) {
            console.log(err);
            res.status(500).send({ message: 'Server error' });
        }
    }
}

module.exports = verifyToken;