const db = require("./databaseConfig");
const crypto = require('crypto');

const secure = {
    gen_secret: (result) => {
        return crypto.createHash('sha256').update(result).digest('base64');
    },

    get_info: (userid) => {
        return new Promise((resolve, reject) => {
            var conn = db.getConnection();
    
            conn.connect(function (err) {
                if (err) {
                    console.log(err);
                    reject(err);
                } else {
                    let sql = 'select * from user where userid=?';
    
                    conn.query(sql, [userid], function (err, result) {
                        conn.end();
    
                        if (err) {
                            console.log("Err: " + err);
                            reject(err);
                        } else {
                            if (result.length == 1) {
                                resolve(secure.gen_secret(JSON.stringify(result[0])));
                            } else {
                                var err2 = new Error("UserID does not match.");
                                err2.statusCode = 500;
                                reject(err2);
                            }
                        }
                    });
                }
            });
        });
    }    

}

module.exports = secure