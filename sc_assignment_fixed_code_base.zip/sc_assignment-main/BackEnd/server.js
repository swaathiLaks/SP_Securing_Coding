
const app = require('./controller/app');
const https = require('https');
const fs = require('fs');

const hostname = "localhost";
const port = 8081;

const options = {
    key: fs.readFileSync('./ssl/private-key.pem', 'utf8'),  // Specify 'utf8' encoding
    cert: fs.readFileSync('./ssl/certificate.pem', 'utf8'),  // Specify 'utf8' encoding
};

const server = https.createServer(options, app);

server.listen(port, hostname, () => {
    console.log(`Server hosted at https://${hostname}:${port}`);
});

server.on('error', (error) => {
    if (error.code === 'EADDRINUSE') {
        console.error(`Port ${port} is already in use. Choose a different port.`);
    } else {
        console.error('Server error:', error);
    }
});
